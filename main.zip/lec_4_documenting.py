def crutoi_chuvak(a=1, b=1, c=1):
  '''Это функция
  '''
  a='pofig'
  b='pofig'
  print('Крутой чувак')
crutoi_chuvak()
help(crutoi_chuvak)